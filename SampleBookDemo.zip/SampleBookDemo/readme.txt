This demo demonstrates use of Single Controller - using servlets/html.
This demo could be used during Servlet 3.0 - training session.

Trainees will get an idea how a single controller can be mapped to multiple requests along with layered architecture.