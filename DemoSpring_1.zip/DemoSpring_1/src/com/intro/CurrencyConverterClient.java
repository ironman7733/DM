package com.intro;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.*;
import org.springframework.core.io.*;

public class CurrencyConverterClient {

	public static void main(String args[]) throws Exception {
		Resource res = new ClassPathResource("currencyconverter.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		CurrencyConverter curr = (CurrencyConverter) factory.getBean("currencyConverter");
		
	//	CurrencyConverter obj = new CurrencyConverterImpl();
		System.out.println(curr.hashCode());
		double rupees = curr.dollarsToRupees(50.0);
		System.out.println("50 $ is "+rupees+" Rs.");
		
CurrencyConverter curr1 = (CurrencyConverter) factory.getBean("currencyConverter");
		
		
		System.out.println(curr1.hashCode());
		
	}
}
