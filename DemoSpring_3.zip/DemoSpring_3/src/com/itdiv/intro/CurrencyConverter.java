package com.itdiv.intro;
public interface CurrencyConverter {

	public double dollarsToRupees(double dollars);
	
}