package com.itdiv.intro;

public interface ExchangeService {

	public double getExchangeRate();
}
