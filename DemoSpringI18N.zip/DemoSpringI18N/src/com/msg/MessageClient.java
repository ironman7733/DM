package com.msg;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageClient {

	public static void main(String args[]) throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("message.xml");
		//load a bean class directly without wating to create an object
		MessageSource messageSource = (MessageSource) ctx.getBean("messageSource");
		Locale locale = new Locale("en","US");
		//second parameter is null , bcz we are accessing the existing mesage
		String msg = messageSource.getMessage("welcome.message",null,locale);
		System.out.println(msg);
	}
}
