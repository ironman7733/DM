package com.capgemini.lesson22.thread;

public class HelloThread extends Thread {

public void run(){
	
	
	System.out.println("Hello ..  Welcome to Capgemini.");
	
}

}
