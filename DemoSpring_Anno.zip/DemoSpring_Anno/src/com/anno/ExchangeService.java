package com.anno;

public interface ExchangeService {
	public double getExchangeRate();
}
