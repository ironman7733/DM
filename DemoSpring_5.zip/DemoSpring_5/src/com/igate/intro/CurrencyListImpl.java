package com.igate.intro;

//import java.util.ArrayList;
import java.util.HashSet;
//import java.util.List;

public class CurrencyListImpl implements CurrencyList{
	
	//private ArrayList<String> currList;
	private HashSet<String> currList;

	public HashSet<String> getCurrList() {
		return currList;
	}

	public void setCurrList(HashSet<String> currList) {
		this.currList = currList;
	}

	/*public HashSet<String> getCurrList() {
		return currList;
	}

	public void setCurrList(HashSet<String> currList) {
		this.currList = currList;
	}*/
	
	
	

}
